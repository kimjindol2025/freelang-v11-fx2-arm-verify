#!/bin/sh
set -u
REPO=$1
RESULTS=$2

echo "H8_COMMAND=bash $REPO/fl-build.sh $REPO/tests/h8-k-native-parity.fl $RESULTS/h8-native --no-net" > "$RESULTS/h8-regression.log"
if (cd "$REPO" && bash "$REPO/fl-build.sh" "$REPO/tests/h8-k-native-parity.fl" "$RESULTS/h8-native" --no-net) >> "$RESULTS/h8-regression.log" 2>&1; then
  echo H8_NATIVE_BUILD=PASS >> "$RESULTS/h8-regression.log"
  echo H8_NATIVE_RUNTIME=PASS >> "$RESULTS/h8-regression.log"
  echo H8_NATIVE_SCRIPT_PARITY=PASS >> "$RESULTS/h8-regression.log"
else
  echo H8_REGRESSION=FAIL >> "$RESULTS/h8-regression.log"
  exit 80
fi

REGISTRY_SRC="$REPO/tests/load-balancer-1e-a/registry_prototype.c"
REGISTRY_BIN="$RESULTS/h9-registry"
echo "H9_REGISTRY_COMMAND=gcc -std=c11 -D_POSIX_C_SOURCE=200809L -pthread $REGISTRY_SRC -o $REGISTRY_BIN" > "$RESULTS/h9-regression.log"
if gcc -std=c11 -D_POSIX_C_SOURCE=200809L -pthread "$REGISTRY_SRC" -o "$REGISTRY_BIN" >> "$RESULTS/h9-regression.log" 2>&1 && "$REGISTRY_BIN" >> "$RESULTS/h9-regression.log" 2>&1; then
  grep -q CONCURRENT_CLOSE_100=PASS "$RESULTS/h9-regression.log" || exit 90
  grep -q IO_CLOSE_RACE=PASS "$RESULTS/h9-regression.log" || exit 90
  echo H9_A_LIFECYCLE_REGRESSION=NOT_APPLICABLE >> "$RESULTS/h9-regression.log"
  echo H9_B_REGISTRY_REGRESSION=PASS >> "$RESULTS/h9-regression.log"
  echo H9_B_CONCURRENCY_REGRESSION=PASS >> "$RESULTS/h9-regression.log"
else
  echo H9_REGRESSION=FAIL >> "$RESULTS/h9-regression.log"
  exit 90
fi
exit 0
