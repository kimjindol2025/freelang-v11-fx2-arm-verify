H9-B2 SELF-CONTAINED EXTERNAL VERIFICATION BUNDLE

Run on a normal x86_64 Linux host:
  ./run-h9-b2-verification.sh --repo /path/to/freelang-v11-fx2-aarch64-v3

The repository path must contain the current IMPL-1 source and both fixtures:
  runtime/async.c
  runtime/runtime.h
  tests/h9-b2-terminal-arbitration.c
  tests/h9-b2-close-race.c

This runner does not implement or alter runtime semantics. It records the
release=join+resource-release contract and executes the existing fixtures.
The historical async adapter is intentionally not fabricated; absence returns
exit code 60 and keeps final closure BLOCKED.

Expected source base:
  356e88800cb64b3b3f562a3b9aebe2ed45f9b46a

The runner creates results/ with raw logs, commands, environment, hashes, and
FINAL-REPORT.txt. Exit codes: 0 all pass, 10 preflight, 20 build, 30 IMPL-1,
40 release race, 50 sanitizer, 60 historical adapter, 70 regression,
80 reproducibility.
