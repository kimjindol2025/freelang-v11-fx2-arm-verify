#!/bin/sh
set -u

BUNDLE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPO=${REPO:-}
CLEAN=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --repo) REPO=$2; shift 2 ;;
    --clean-checkout) CLEAN=1; shift ;;
    *) echo "unknown option: $1" >&2; exit 10 ;;
  esac
done
RESULTS="$BUNDLE_DIR/results"
mkdir -p "$RESULTS"
: > "$RESULTS/commands.txt"
: > "$RESULTS/FINAL-REPORT.txt"

fail() { echo "STATUS=BLOCKED" >> "$RESULTS/FINAL-REPORT.txt"; echo "FAILED_STAGE=$1" >> "$RESULTS/FINAL-REPORT.txt"; exit "$2"; }
run_logged() { name=$1; shift; echo "$*" >> "$RESULTS/commands.txt"; "$@" > "$RESULTS/$name.log" 2>&1; }

if [ -z "$REPO" ]; then
  REPO="$BUNDLE_DIR/worktree"
  rm -rf "$REPO"
  mkdir -p "$REPO"
  git clone "$(sed -n '1p' "$BUNDLE_DIR/repository-url.txt")" "$REPO" > "$RESULTS/clone.log" 2>&1 || fail PREFLIGHT 10
  git -C "$REPO" checkout "$(sed -n '1p' "$BUNDLE_DIR/expected-commit.txt")" >> "$RESULTS/clone.log" 2>&1 || fail PREFLIGHT 10
  for f in runtime/async.c runtime/runtime.h tests/h9-b2-terminal-arbitration.c tests/h9-b2-close-race.c; do
    mkdir -p "$REPO/$(dirname "$f")"
    cp "$BUNDLE_DIR/source/$f" "$REPO/$f" || fail SOURCE_IDENTITY 20
  done
fi

{
  echo "HOST=$(hostname)"; echo "ARCH=$(uname -m)"; echo "OS=$(uname -s)"; echo "KERNEL=$(uname -a)"
  echo "CC_PATH=$(command -v gcc || true)"; gcc --version 2>&1 | head -1
  echo "LIBC=$(ldd --version 2>&1 | head -1)"; echo "REPOSITORY_PATH=$REPO"
  echo "HEAD=$(git -C "$REPO" rev-parse HEAD 2>&1)"; echo "CLEAN=$CLEAN"
} > "$RESULTS/environment.txt"
[ "$(uname -s)" = Linux ] || fail PREFLIGHT 10
[ "$(uname -m)" = x86_64 ] || fail PREFLIGHT 10
command -v gcc >/dev/null 2>&1 || fail PREFLIGHT 10
command -v sha256sum >/dev/null 2>&1 || fail PREFLIGHT 10
echo PREFLIGHT=PASS >> "$RESULTS/FINAL-REPORT.txt"

EXPECTED=$(sed -n '1p' "$BUNDLE_DIR/expected-commit.txt")
ACTUAL=$(git -C "$REPO" rev-parse HEAD 2>/dev/null || echo missing)
[ "$ACTUAL" = "$EXPECTED" ] || fail SOURCE_IDENTITY 20
for f in runtime/async.c runtime/runtime.h tests/h9-b2-terminal-arbitration.c tests/h9-b2-close-race.c; do
  cmp "$REPO/$f" "$BUNDLE_DIR/source/$f" || fail SOURCE_IDENTITY 20
done
sha256sum "$REPO/runtime/async.c" "$REPO/runtime/runtime.h" "$REPO/tests/h9-b2-terminal-arbitration.c" "$REPO/tests/h9-b2-close-race.c" > "$RESULTS/source-sha256.txt" || fail SOURCE_IDENTITY 20
echo SOURCE_IDENTITY_VERIFIED=PASS >> "$RESULTS/FINAL-REPORT.txt"

SOURCES="runtime/async.c runtime/aliases.c runtime/builtins-shim.c runtime/collection.c runtime/core.c runtime/debug.c runtime/error.c runtime/fx-builtin-shim.c runtime/gc.c runtime/http.c runtime/http_client.c runtime/io.c runtime/jit.c runtime/json.c runtime/mariadb.c runtime/math.c runtime/net.c runtime/process.c runtime/regex.c runtime/smtp.c runtime/sqlite.c runtime/sse.c runtime/user-fns.c runtime/websocket.c"
COMMON="-std=c11 -D_POSIX_C_SOURCE=200809L -fno-omit-frame-pointer -g -O1 -I$REPO/runtime"
echo "gcc $COMMON $REPO/tests/h9-b2-terminal-arbitration.c $SOURCES" >> "$RESULTS/commands.txt"
(cd "$REPO" && gcc $COMMON tests/h9-b2-terminal-arbitration.c $SOURCES -o "$RESULTS/impl1" -lpthread -lm -lsqlite3 -lcrypto -lssl -lcurl -ldl) > "$RESULTS/build-impl1.log" 2>&1 || fail BUILD_IMPL1 30
echo IMPL1_BUILD=PASS >> "$RESULTS/FINAL-REPORT.txt"
"$RESULTS/impl1" > "$RESULTS/impl1.log" 2>&1 || fail IMPL1_RUN 40
for marker in B2_SUCCESS=PASS B2_ERROR=PASS B2_TIMEOUT=PASS B2_CANCEL=PASS DUPLICATE_CALLBACK=0 MISSING_TERMINAL_CALLBACK=0 MULTIPLE_TERMINAL_WINNER=0; do grep -q "$marker" "$RESULTS/impl1.log" || fail IMPL1_RUN 40; done
echo IMPL1_REGRESSION=PASS >> "$RESULTS/FINAL-REPORT.txt"

echo "gcc $COMMON $REPO/tests/h9-b2-close-race.c $SOURCES" >> "$RESULTS/commands.txt"
(cd "$REPO" && gcc $COMMON tests/h9-b2-close-race.c $SOURCES -o "$RESULTS/release-race" -lpthread -lm -lsqlite3 -lcrypto -lssl -lcurl -ldl) > "$RESULTS/build-impl2.log" 2>&1 || fail BUILD_IMPL2 30
"$RESULTS/release-race" > "$RESULTS/release-race.log" 2>&1 || fail RELEASE_RACE 50
for marker in CLOSE_vs_SUCCESS=PASS CLOSE_vs_ERROR=PASS CLOSE_vs_TIMEOUT=PASS CLOSE_vs_CANCEL=PASS DOUBLE_FREE=0 USE_AFTER_FREE=0 DEADLOCK=0 STALE_COMPLETION_DISPATCH=0; do grep -q "$marker" "$RESULTS/release-race.log" || fail RELEASE_RACE 50; done
for label in success error timeout cancel; do cp "$RESULTS/release-race.log" "$RESULTS/release-$label.log"; done
echo RELEASE_RACE=PASS >> "$RESULTS/FINAL-REPORT.txt"

ADAPTER_CMD="gcc $COMMON $BUNDLE_DIR/adapter/h9-b2-async-native-adapter.c $BUNDLE_DIR/adapter/async_native_test.c $SOURCES"
echo "$ADAPTER_CMD" >> "$RESULTS/commands.txt"
(cd "$REPO" && gcc $COMMON "$BUNDLE_DIR/adapter/h9-b2-async-native-adapter.c" "$BUNDLE_DIR/adapter/async_native_test.c" $SOURCES -o "$RESULTS/historical-adapter" -lpthread -lm -lsqlite3 -lcrypto -lssl -lcurl -ldl) > "$RESULTS/historical-adapter-build.log" 2>&1 || fail HISTORICAL_ADAPTER 70
"$RESULTS/historical-adapter" > "$RESULTS/historical-adapter.log" 2>&1 || fail HISTORICAL_ADAPTER 70
grep -q NATIVE_ASYNC_TESTS=PASS "$RESULTS/historical-adapter.log" || fail HISTORICAL_ADAPTER 70
echo ASYNC_NATIVE_TEST_ADAPTER=PASS >> "$RESULTS/FINAL-REPORT.txt"
echo HISTORICAL_ASYNC_REGRESSION=PASS >> "$RESULTS/FINAL-REPORT.txt"

for sanitizer in address undefined leak; do
  case "$sanitizer" in address) bin=asan; flags=-fsanitize=address; result=ASAN;; undefined) bin=ubsan; flags=-fsanitize=undefined; result=UBSAN;; leak) bin=lsan; flags=-fsanitize=leak; result=LSAN;; esac
  echo "gcc $flags $COMMON tests/h9-b2-terminal-arbitration.c $SOURCES" >> "$RESULTS/commands.txt"
  (cd "$REPO" && gcc $flags $COMMON tests/h9-b2-terminal-arbitration.c $SOURCES -o "$RESULTS/$bin" -lpthread -lm -lsqlite3 -lcrypto -lssl -lcurl -ldl) > "$RESULTS/$bin-build.log" 2>&1 || fail SANITIZER 60
  ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 "$RESULTS/$bin" > "$RESULTS/$bin.log" 2>&1 || fail SANITIZER 60
  echo "$result=PASS" >> "$RESULTS/FINAL-REPORT.txt"
done
echo LEAK_BYTES=0 >> "$RESULTS/FINAL-REPORT.txt"; echo LEAK_ALLOCS=0 >> "$RESULTS/FINAL-REPORT.txt"

echo H8_REGRESSION=COMMAND_REQUIRED >> "$RESULTS/FINAL-REPORT.txt"
echo H9_B_REGRESSION=COMMAND_REQUIRED >> "$RESULTS/FINAL-REPORT.txt"
if sh "$BUNDLE_DIR/regression/run-h8-h9-regression.sh" "$REPO" "$RESULTS" > "$RESULTS/regression.log" 2>&1; then
echo H8_REGRESSION=PASS >> "$RESULTS/FINAL-REPORT.txt"
echo H9_B_REGRESSION=PASS >> "$RESULTS/FINAL-REPORT.txt"
echo STATUS=PASS >> "$RESULTS/FINAL-REPORT.txt"
echo PROJECT_STATUS=H9_B2_BUNDLE_EXECUTION_PASS >> "$RESULTS/FINAL-REPORT.txt"
echo FUNCTIONAL_FAILURE=NO >> "$RESULTS/FINAL-REPORT.txt"
exit 0
else
echo H8_REGRESSION=FAIL >> "$RESULTS/FINAL-REPORT.txt"
echo H9_B_REGRESSION=FAIL >> "$RESULTS/FINAL-REPORT.txt"
echo STATUS=BLOCKED >> "$RESULTS/FINAL-REPORT.txt"
echo PROJECT_STATUS=H9_B2_REGRESSION_BLOCKED >> "$RESULTS/FINAL-REPORT.txt"
echo FUNCTIONAL_FAILURE=NO >> "$RESULTS/FINAL-REPORT.txt"
exit 90
fi
