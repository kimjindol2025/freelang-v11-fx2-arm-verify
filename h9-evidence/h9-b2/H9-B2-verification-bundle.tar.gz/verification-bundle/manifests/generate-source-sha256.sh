#!/bin/sh
set -eu
ROOT=${1:-.}
OUT=${2:-$ROOT/manifests/SOURCE-SHA256SUMS}
sha256sum "$ROOT/source/runtime/async.c" "$ROOT/source/runtime/runtime.h" "$ROOT/source/tests/h9-b2-terminal-arbitration.c" "$ROOT/source/tests/h9-b2-close-race.c" > "$OUT"
