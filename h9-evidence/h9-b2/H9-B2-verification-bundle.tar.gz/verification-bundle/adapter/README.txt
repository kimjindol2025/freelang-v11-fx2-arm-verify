ADAPTER_STATUS=BLOCKED
REASON=historical async_native_test.c uses async_* ABI while current runtime exposes fl_async_* ABI; no provenance-preserving adapter has been created.
The runner must report exit code 60 rather than fabricate a PASS.
