#include "runtime.h"
#include <string.h>

static int adapter_permissions = 1;

static FLValue adapter_error(const char *name) {
    FLValue m = fl_map_new();
    m = fl_map_set(m, fl_str_val("status"), fl_str_val("error"));
    m = fl_map_set(m, fl_str_val("errorType"), fl_str_val(name));
    return m;
}

static FLValue adapter_timeout(FLValue task, FLValue ms) {
    FLValue m = fl_map_new();
    m = fl_map_set(m, fl_str_val("__adapter_timeout_task__"), task);
    return fl_map_set(m, fl_str_val("__adapter_timeout_ms__"), ms);
}

FLValue async_set_permissions(FLValue root, FLValue write_root, FLValue host) {
    (void)root; (void)write_root; (void)host;
    adapter_permissions = root.tag != FL_NIL;
    return fl_bool(true);
}

FLValue async_read_file(FLValue path) {
    return adapter_permissions ? fl_async_file_read(path) : adapter_error("PermissionDeniedError");
}
FLValue async_write_file(FLValue path, FLValue content) {
    return adapter_permissions ? fl_async_file_write(path, content) : adapter_error("PermissionDeniedError");
}
FLValue async_fetch(FLValue url) {
    return adapter_permissions ? fl_async_http_get(url, fl_nil()) : adapter_error("PermissionDeniedError");
}
FLValue async_sleep(FLValue ms) { return fl_async_sleep(ms); }
FLValue async_timeout(FLValue task, FLValue ms) { return adapter_timeout(task, ms); }
FLValue async_cancel(FLValue task) { return fl_async_cancel(task); }
FLValue async_set_concurrency(FLValue value) { (void)value; return fl_bool(true); }

FLValue async_await(FLValue task) {
    FLValue marker = fl_map_get(task, fl_str_val("errorType"));
    if (marker.tag == FL_STRING) return task;
    FLValue timeout = fl_map_get(task, fl_str_val("__adapter_timeout_ms__"));
    FLValue target = fl_map_get(task, fl_str_val("__adapter_timeout_task__"));
    FLValue result = timeout.tag == FL_INT ? fl_async_await(target, timeout) : fl_async_await(task, fl_int(30000));
    FLValue status = fl_map_get(result, fl_str_val("status"));
    if (status.tag == FL_STRING && strcmp(((FLString *)status.obj)->data, "ok") == 0)
        return fl_map_get(result, fl_str_val("value"));
    return result;
}
